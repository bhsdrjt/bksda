<ol class="breadcrumb bc-3">
    <li>
        <a href="<?php echo base_url() ?>app">
            <i class="fa fa-file"></i>App</a>
    </li>
    <li class="active">
        <strong>Tentang Aplikasi</strong> 
    </li>
</ol>

<h3>Tentang</h3> 
<div class="row"> 
    <div class="col-md-6" style="min-height:650px">
    	<img src="<?php echo base_url() ?>assets/images/pu.png" width="100" style="margin-right:5px;" />
        <h4>Situation Room Balai Konservasi Sumber Daya Alam Kalimantan Selatan</h4>
        <p>Versi 1.0</p>
    </div>
</div>  

