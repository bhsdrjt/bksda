<ol class="breadcrumb bc-3">
    <li>
        <a href="<?php echo base_url() ?>app">
            <i class="fa fa-file"></i>App</a>
    </li>
    <li class="active">
        <strong>Data kawasan</strong> 
    </li>
</ol>

<h3>Data kawasan</h3> 
<div class="row">
    <div class="col-md-12">
        <div id="map-canvas" style="height: 800px;"> </div>
         
    </div>
</div>  

